package ER_Management_System;

public class MainClass {

    public static void main(String[] args) {
        HomePage frame = new HomePage();
        frame.setVisible(true);
    }
    
}
