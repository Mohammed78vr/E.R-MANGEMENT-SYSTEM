package ER_Management_System;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class SearchForUser {

    private String db_url = "jdbc:mysql://localhost:3306/er";
    private String db_username = "root";
    private String db_password = "1234";
    private Connection con = null;
    private Statement state = null;
    private ResultSet result = null;

    public SearchForUser() {
        // connect to the database
        try {
            con = DriverManager.getConnection(
                    db_url,
                    db_username,
                    db_password);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public boolean SearchForAdmin(String username, String password) {
        String query = "SELECT Username, Password FROM admin;";
        try {
            state = con.createStatement();
            result = state.executeQuery(query);
            // Search for the username and password that is equal to what the user enter
            // in the database
            while (result.next()) {
                if (username.equals(result.getString("Username"))
                        && password.equals(result.getString("Password"))) {
                    return true;
                }
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    public String SearchForEmployee(String username, String password) {
        String query = "SELECT empId, Password, Job FROM employees;";
        String job;
        try {
            int empID = Integer.parseInt(username);
            state = con.createStatement();
            result = state.executeQuery(query);
            // Search for the username and password that is equal to what the user enter
            // in the database
            int id;
            while (result.next()) {
                id = (int) result.getObject(1);
                if (empID == id
                        && password.equals(result.getString("Password"))) {
                    job = result.getString("Job");
                    return job;
                }
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
       return "";
    }

}
